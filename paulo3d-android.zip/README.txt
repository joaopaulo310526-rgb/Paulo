Paulo 3D Studio - projeto Android (WebView)
Android Studio: abrir a pasta > Build > Build APK(s). APK em app/build/outputs/apk/debug/app-debug.apk
Sem computador: usar o workflow build.yml no GitHub Actions (ver instrucoes no chat).
Exportacoes (GLB, OBJ, STL...) sao salvas em Downloads/Paulo3D.
